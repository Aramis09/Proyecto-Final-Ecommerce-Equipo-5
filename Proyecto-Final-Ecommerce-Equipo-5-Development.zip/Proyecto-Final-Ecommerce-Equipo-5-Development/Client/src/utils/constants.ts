export const LIST_PRODUCTS='http://localhost:3001/products/';
export const LIST_PRODUCTS_BY_PLATFORMS='http://localhost:3001/products/platforms';
export const LIST_PRODUCTS_BY_FILTERS='http://localhost:3001/products/multiple';
export const LIST_PLATFORMS='http://localhost:3001/platforms/';
export const LIST_GENRES='http://localhost:3001/genres/';