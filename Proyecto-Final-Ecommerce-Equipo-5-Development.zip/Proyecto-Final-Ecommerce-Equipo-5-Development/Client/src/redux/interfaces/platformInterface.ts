export interface platformReducerState{
    listPlatformsData: Array<object>,
    details: object,
    successMsg: string,
    errorMsg: string
}