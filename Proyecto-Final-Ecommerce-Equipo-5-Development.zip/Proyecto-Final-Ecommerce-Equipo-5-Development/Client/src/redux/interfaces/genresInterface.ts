export interface genresReducerState{
    listGenresData: Array<object>,
    idDetails: object,
    successMsg: string,
    errorMsg: string
}